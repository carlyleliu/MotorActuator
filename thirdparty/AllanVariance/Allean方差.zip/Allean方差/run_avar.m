%load('E:\毕业设计\allan\matlab_allan.mat')     %数据加载
load testData.mat
x = mydata;
data=x;
tao0=1/50;   %采样周期5ms
[sigma,tau,Err]=avar(x,tao0);